#include <LPC21xx.h>        // Include LPC214x register definitions
#include "type.h"           // Include custom type definitions (u8, u16, f32, etc.)
#include "defines.h"        // Include global project defines
#include "adc_defines.h"    // Include ADC-specific register/bit defines
#include "delay.h"          // Include delay functions


// Function to initialize ADC
void Init_ADC(void)
{
    PINSEL1 = 0x01000000;   // Configure P0.28 as ADC channel pin (AD0.1 input)
    ADCR = PDN_BIT | CLKDIV; // Power-up ADC and set clock division factor
}


// Function to read ADC value from given channel number (chNo)
f32 Read_ADC(u8 chNo)
{
    u16 adcVal = 0;         // Variable to store raw ADC value (10-bit result)
    f32 eAR;                // Variable to store equivalent analog reading in volts

    ADCR &= 0xFFFFFF00;     // Clear channel selection bits in ADCR
    // WRITEBYTE(ADCR,0,chNo); ? Alternative macro approach (commented)
    ADCR |= 1 << chNo;      // Select the requested ADC channel
    // SETBIT(ADCR,ADC_START_BIT); ? Alternative macro approach (commented)
    ADCR |= 1 << ADC_START_BIT; // Start ADC conversion
    delay_us(3);                // Small delay for conversion to stabilize

    while (((ADDR >> DONE_BIT) & 1) == 0); // Wait until conversion is complete (DONE bit set)

    // CLRBIT(ADCR,ADC_START_BIT); ? Alternative macro approach (commented)
    ADCR &= ~(1 << ADC_START_BIT);  // Stop ADC conversion
    adcVal = (ADDR >> 6) & 0x3FF;   // Extract 10-bit ADC result (bits 15:6)

    eAR = ((adcVal * 3.3) / 1023);  // Convert raw ADC value to equivalent analog voltage (0�3.3V)

    return eAR;                     // Return the analog voltage
}
