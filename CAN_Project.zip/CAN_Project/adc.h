#ifndef _ADC_H_        // Prevent multiple inclusion of this header file (include guard start)

#define _ADC_H_        // Define a unique identifier for this header file


#include "type.h"      // Include user-defined type definitions (for f32, u8, etc.)

void Init_ADC(void);   // Function prototype: Initialize the ADC peripheral

f32 Read_ADC(u8 chNo); // Function prototype: Read analog value from ADC channel 'chNo'
                       // Returns the converted value as float (f32)


#endif                 // End of include guard (_ADC_H_)
