#include <lpc21xx.h>        // LPC21xx register definitions
#include "can.h"            // CAN function prototypes
#include "can_defines.h"    // CAN register/bit defines
#include "adc.h"            // ADC function prototypes
#include "adc_defines.h"    // ADC register/bit defines
#include "type.h"           // Custom typedefs (u8, u16, f32, etc.)
#include "delay.h"          // Delay functions (us, ms, s)
#include "lcd.h"            // LCD display functions

float ar;                   // Variable to store analog voltage reading
int fuel;                   // Variable to store calculated fuel percentage

int main()
{
    struct CAN_Frame txFrame;   // Define CAN frame structure for transmission

    Initlcd();                  // Initialize LCD
    Init_ADC();                 // Initialize ADC
    Init_CAN1();                // Initialize CAN controller

    txFrame.ID = 4;             // Assign CAN message ID = 4
    txFrame.vbf.RTR = 0;        // Data frame (not remote request)

    strlcd("fuel:");            // Display label "fuel:" on LCD

    while(1)
    {
        // Step 1: Read analog value from ADC channel 1 (fuel sensor)
        ar = Read_ADC(1);

        // Step 2: Convert ADC voltage into percentage (0�100%)
        fuel = ((ar - 0.461) / (3.299 - 0.461)) * 100;

        // Step 3: Apply boundaries to avoid invalid percentages
        if(fuel <= 0)
        {
            fuel = 0;           // Minimum fuel = 0%
        }
        else if(fuel > 99)
        {
            fuel = 99;          // Maximum fuel = 99% (to fit 2-digit display)
        }

        // Step 4: Prepare CAN frame
        txFrame.vbf.RTR = 0;    // Data frame
        txFrame.Data1 = fuel;   // Put fuel % in Data1
        txFrame.vbf.DLC = 4;    // Data length = 4 bytes

        // Step 5: Transmit CAN message
        CAN1_Tx(txFrame);

        // Step 6: Show results on LCD
        F32lcd(ar, 3);          // Display ADC voltage with 3 decimals
        delay_ms(500);

        cmdlcd(0xc0);           // Move cursor to 2nd line
        U32lcd(fuel);           // Display fuel percentage
        delay_s(2);             // Wait 2 seconds

        cmdlcd(0x01);           // Clear LCD for next update
    }
}
