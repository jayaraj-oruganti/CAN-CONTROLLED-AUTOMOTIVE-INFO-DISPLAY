#include <LPC21xx.h>           // LPC21xx register definitions
#include "type.h"               // Type definitions like u32, s32
#include "lcd.h"                // LCD driver functions
#include "lcd_defines.h"        // LCD macros like GOTO_LINEx_POSx
#include "delay.h"              // Delay functions

// System clock and peripheral clock macros
#define FOSC    12000000       // Crystal oscillator frequency = 12 MHz
#define CCLK    (5*FOSC)       // CPU clock (CCLK = 5 * FOSC)
#define PCLK    (CCLK/4)       // Peripheral clock (PCLK = CCLK / 4)

// RTC prescaler macros
#define PREINT_VAL   (int)((PCLK / 32768) - 1)   // Integer part for RTC prescaler
#define PREFRAC_VAL  (PCLK - ((PREINT + 1) * 32768))  // Fractional part for RTC prescaler

// RTC control bits
#define RTC_ENABLE    (1<<0)    // Enable RTC
#define RTC_RESET     (1<<1)    // Reset RTC
#define RTC_CLKSRC_EX (1<<4)    // Use external clock source for RTC

// Global variables for RTC
s32 hour, min, sec, date, month, year, day;     // Store time and date
char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"}; // Weekday names

// RTC Initialization: Configures and enables the RTC
void RTC_Init(void) 
{
    CCR = RTC_RESET;                  // Disable and reset the RTC
    PREINT = PREINT_VAL;              // Set prescaler integer part
    PREFRAC = PREFRAC_VAL;            // Set prescaler fractional part

    CCR = RTC_ENABLE | RTC_CLKSRC_EX; // Enable RTC with external clock (for LPC2148)
    // CCR = RTC_ENABLE;               // For LPC2129 (commented out)
}

// Get current time from RTC registers
void GetRTCTime(s32 *hour, s32 *min, s32 *sec)
{
    *hour = HOUR;                     // Read hours from RTC
    *min  = MIN;                      // Read minutes
    *sec  = SEC;                      // Read seconds
}

// Display RTC time on LCD at a specific position
void DisplayRTCTime(u32 hour, u32 min, u32 sec)
{
    cmdlcd(GOTO_LINE2_POS0+11);      // Move cursor to line 2, position 11
    charlcd((hour/10)+48);           // Tens digit of hour
    cmdlcd(GOTO_LINE2_POS0+12);
    charlcd((hour%10)+48);           // Units digit of hour
    cmdlcd(GOTO_LINE2_POS0+13);
    charlcd(':');                     // Separator
    cmdlcd(GOTO_LINE2_POS0+14);
    charlcd((min/10)+48);            // Tens digit of minute
    cmdlcd(GOTO_LINE2_POS0+15);
    charlcd((min%10)+48);            // Units digit of minute
    cmdlcd(GOTO_LINE2_POS0+16);
    charlcd(':');                     // Separator
    cmdlcd(GOTO_LINE2_POS0+17);
    charlcd((sec/10)+48);            // Tens digit of second
    cmdlcd(GOTO_LINE2_POS0+18);
    charlcd((sec%10)+48);            // Units digit of second
}

// Set RTC time
void SetRTCTime(u32 hr, u32 mi, u32 se)
{
    HOUR = hr;                        // Set hour
    MIN  = mi;                        // Set minute
    SEC  = se;                        // Set second
}

// Get current date from RTC
void GetRTCDate(s32 *date, s32 *month, s32 *year)
{
    *date  = DOM;                     // Day of month
    *month = MONTH;                   // Month
    *year  = YEAR;                    // Year
}

// Display date on LCD in DD/MM/YYYY format
void DisplayRTCDate(u32 date, u32 month, u32 year)
{
    cmdlcd(GOTO_LINE2_POS0);          // Move cursor to line 2
    charlcd((date/10)+48);            // Tens digit of day
    charlcd((date%10)+48);            // Units digit of day
    charlcd('/');                     // Separator
    charlcd((month/10)+48);           // Tens digit of month
    charlcd((month%10)+48);           // Units digit of month
    charlcd('/');                     // Separator
    U32lcd(year);                     // Display full 4-digit year
}

// Set RTC date
void SetRTCDate(u32 date, u32 month, u32 year)
{
    DOM   = date;                     // Set day of month
    MONTH = month;                    // Set month
    YEAR  = year;                     // Set year
}

// Get current day of week from RTC
void GetRTCDay(s32 *day)
{
    *day = DOW;                        // Read day of week (0=Sunday)
}

// Display day of week on LCD
void DisplayRTCDay(u32 day)
{
    cmdlcd(GOTO_LINE1_POS0+10);       // Move cursor to line 1
    strlcd(week[day]);                // Display weekday string
}

// Set day of week
void SetRTCDay(u32 day)
{
    DOW = day;                         // Write day of week (0=Sunday, 6=Saturday)
}
