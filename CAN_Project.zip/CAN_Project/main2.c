#include <LPC21xx.h>   
#include"delay.h"
#include"can.h"   
#define led 0
main()   

{   
	u32 i;
	struct CAN_Frame rxFrame;   
	IODIR0|=0XFF<<led;
  Init_CAN1();   

	while(1)   

	{   

        CAN1_Rx(&rxFrame);  
				if(rxFrame.ID==2&&rxFrame.Data1==0x87654321&&rxFrame.Data2==0x38392635)
				{
				for(i=0;i<8;i++)
				{
				IOPIN0=rxFrame.Data2<<led;
				delay_ms(200);
				IOPIN0=0XFF<<led;
				}
				}
				    

	}    

	

}   