#include <LPC21XX.h>               // Header file for LPC21xx registers
#include "type.h"                  // Custom typedefs (u8, u16, u32, etc.)
#include "delay.h"                 // Delay functions
#include "external_interrupt.h"    // External interrupt header
#include "lcd.h"                   // LCD display functions
#include "lcd_defines.h"           // LCD command/data defines
#include "pin_connect_block.h"     // Pin configuration functions
#include "can.h"                   // CAN driver
#include "can_defines.h"           // CAN defines

#define eint1_vic_ch0 15           // VIC channel number for EINT1
#define eint0_vic_ch0 14           // VIC channel number for EINT0

u32 count = 0, count1 = 0;         // General counters (not used here)

extern u32 flag2;                  // External flags (shared with main program)
extern u32 flag1;
extern struct CAN_Frame txFrame;   // CAN frame structure (defined elsewhere)

/** ISR for External Interrupt 0 **/
void eint0_isr(void) __irq
{
    flag1++;           // Increment flag1 when EINT0 triggered
    flag2 = 0;         // Reset flag2

    // Example LCD debug (commented out)
    // cmdlcd(0xd4);       // Move cursor
    // U32lcd(flag1);      // Print flag1 value
    // cmdlcd(0xd4+5);
    // U32lcd(flag2);      // Print flag2 value

    EXTINT = 1 << 0;   // Clear EINT0 interrupt flag
    VICVectAddr = 0;   // End of interrupt
}

/** ISR for External Interrupt 1 **/
void eint1_isr(void) __irq
{
    flag2++;           // Increment flag2 when EINT1 triggered
    flag1 = 0;         // Reset flag1

    // Example LCD debug (commented out)
    // cmdlcd(0xd4);
    // U32lcd(flag1);
    // cmdlcd(0xd4+5);
    // U32lcd(flag2);

    EXTINT = 1 << 1;   // Clear EINT1 interrupt flag
    VICVectAddr = 0;   // End of interrupt
}

/** Configure and enable External Interrupt 0 **/
void enable_EINT0(void)
{
    CfgPortPinFunc(0,16,1);             // Configure P0.16 as EINT0 function

    VICIntEnable |= 1 << eint0_vic_ch0; // Enable VIC interrupt channel 14 (EINT0)
    VICVectCntl0 = (1 << 5) | eint0_vic_ch0; // Enable slot 0 for EINT0 interrupt
    VICVectAddr0 = (u32)eint0_isr;      // Assign ISR address for EINT0

    // Configure external interrupt block
    // EXTINT = 0;                       // (Clear pending INT if needed)
    EXTMODE |= 1 << 0;                  // Edge-sensitive mode for EINT0
    // EXTPOLAR = 1 << 0;                // Uncomment if rising-edge trigger required
}

/** Configure and enable External Interrupt 1 **/
void enable_EINT1(void)
{
    CfgPortPinFunc(0,14,2);             // Configure P0.14 as EINT1 function

    VICIntEnable |= 1 << eint1_vic_ch0; // Enable VIC interrupt channel 15 (EINT1)
    VICVectCntl1 = (1 << 5) | eint1_vic_ch0; // Enable slot 1 for EINT1 interrupt
    VICVectAddr1 = (u32)eint1_isr;      // Assign ISR address for EINT1

    // Configure external interrupt block
    // EXTINT = 0;                       // (Clear pending INT if needed)
    EXTMODE |= 1 << 1;                  // Edge-sensitive mode for EINT1
    // EXTPOLAR = 1 << 1;                // Uncomment if rising-edge trigger required
}
