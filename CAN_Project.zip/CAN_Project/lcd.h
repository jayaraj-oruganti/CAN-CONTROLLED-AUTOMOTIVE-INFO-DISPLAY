#include "type.h"                 // Include custom type definitions (u8, u32, s8, f32, etc.)

void writelcd(u8 dat);            // Write a single data byte to LCD (low-level function)

void cmdlcd(u8 cmd);              // Send a command byte to LCD (like clear, cursor move, etc.)

void charlcd(u8 ascii);           // Display a single ASCII character on LCD

void Initlcd(void);               // Initialize the LCD (setup display, cursor, etc.)

void strlcd(s8*);             // Display a string on LCD (takes signed 8-bit pointer)

void U32lcd(u32);             // Display an unsigned 32-bit integer on LCD

void S32lcd(s32);             // Display a signed 32-bit integer on LCD

void F32lcd(f32, u32);   // Display a floating-point number with given precision

void hexalcd(u32 );            // Display a number in hexadecimal format

void octlcd(u32 );             // Display a number in octal format

void binlcd(u32 , u32 );   // Display a number in binary format with given bit-width

void buildcgram(u8*,      // Define a custom character in CGRAM (character generator RAM)
                u8,      // Location (0�7) where custom char will be stored
                int,          // Row position on LCD
                int);         // Column position on LCD
