#include "type.h"              // Include custom type definitions like u32, s32
#include <LPC21xx.h>            // Include LPC21xx microcontroller register definitions

// Function to configure pin function for a specific port and pin
void CfgPortPinFunc(u32 portNo, u32 pinNo, u32 pinF)
{
    if(portNo == 0)             // Check if port number is 0 (P0)
    {
        if(((s32)pinNo >= 0) && (pinNo <= 15))  // If pin number is 0 to 15
        {
            // Clear previous function bits (2 bits per pin) and set new function
            PINSEL0 = ((PINSEL0 & ~(3 << (pinNo * 2))) | (pinF << (pinNo * 2)));
        }
        else if((pinNo >= 16) && (pinNo <= 31)) // If pin number is 16 to 31
        {
            // Clear previous function bits (2 bits per pin) and set new function
            PINSEL1 = ((PINSEL1 & ~(3 << ((pinNo - 16) * 2))) | (pinF << ((pinNo - 16) * 2)));
        }
    }
}
