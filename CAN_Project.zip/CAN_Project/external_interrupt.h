/* External Interrupt (EINT) Function Prototypes */

/* ISR (Interrupt Service Routine) for External Interrupt 0 */
void eint0_isr(void) __irq;  
// __irq indicates that this function is an interrupt handler for EINT0
// This function will be automatically called when EINT0 triggers

/* ISR (Interrupt Service Routine) for External Interrupt 1 */
void eint1_isr(void) __irq;  
// __irq indicates that this function is an interrupt handler for EINT1
// This function will be automatically called when EINT1 triggers

/* Function to enable/configure External Interrupt 0 */
void enable_EINT0(void);  
// Typically sets the interrupt type (edge/level) and enables the EINT0 in the VIC/interrupt controller

/* Function to enable/configure External Interrupt 1 */
void enable_EINT1(void);  
// Typically sets the interrupt type (edge/level) and enables the EINT1 in the VIC/interrupt controller
