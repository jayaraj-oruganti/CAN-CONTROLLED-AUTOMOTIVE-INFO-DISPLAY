typedef unsigned char u8;   // u8: 8-bit unsigned integer (0 to 255)
typedef char s8;            // s8: 8-bit signed integer (-128 to 127)
typedef unsigned short u16; // u16: 16-bit unsigned integer (0 to 65535)
typedef short s16;          // s16: 16-bit signed integer (-32768 to 32767)
typedef unsigned int u32;   // u32: 32-bit unsigned integer (0 to 4294967295)
typedef int s32;            // s32: 32-bit signed integer (-2147483648 to 2147483647)
typedef float f32;          // f32: 32-bit floating point number
