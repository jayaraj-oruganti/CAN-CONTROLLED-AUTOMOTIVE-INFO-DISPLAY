#ifndef _DS18B20_H_          // Include guard start: prevents multiple inclusions
#define _DS18B20_H_


/** ---------------- DS18B20 Function Declarations ---------------- **/

/* Sends a reset pulse to DS18B20 sensor and checks for presence pulse */
unsigned char ResetDS1820(void);  
// Returns 0 if sensor is present, 1 if not (commonly used convention)

/* Reads a single bit from DS18B20 */
unsigned char ReadBit(void);  
// Returns 0 or 1 depending on the bit read from the sensor

/* Writes a single bit to DS18B20 */
void WriteBit(unsigned char bit);  
// Sends 'bit' (0 or 1) to the sensor

/* Reads a full byte (8 bits) from DS18B20 */
unsigned char ReadByte(void);  
// Calls ReadBit 8 times internally and combines the bits

/* Writes a full byte (8 bits) to DS18B20 */
void WriteByte(unsigned char byte);  
// Sends each bit of 'byte' to the sensor using WriteBit

/* Reads temperature from DS18B20 and returns it as an integer */
int ReadTemp(void);  
// Typically returns temperature in Celsius (multiplied by 16 for fractional values, depending on implementation)


#endif  // _DS18B20_H_  // Include guard end
