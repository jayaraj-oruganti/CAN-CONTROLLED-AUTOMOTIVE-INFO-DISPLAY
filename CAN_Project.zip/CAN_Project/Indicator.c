    /*  -------INDICATOR NODE-------  */
#include <LPC21xx.h>       // LPC21xx microcontroller header
#include "can.h"           // CAN driver functions
#include "can_defines.h"   // CAN register/bit defines
#include "delay.h"         // Delay functions
#include "defines.h"       // Custom defines (WRITEBYTE macro etc.)
#include "type.h"          // Data type aliases (u8, u32, etc.)
#include "lcd.h"           // LCD driver functions

#define LEDS 10            // LED connection starting pin (from P0.10 ? P0.17)

struct CAN_Frame rxFrame;  // Global CAN frame for received data
u32 i;                     // Loop counter

// Lookup table for right indicator LED patterns
u8 R_LUT[]={128,192,224,240,248,252,254,255};

// Flags to track left and right indicators
volatile u8 l_s=0;
volatile u8 r_s=0;

// Check if a CAN message is available in the RX buffer
u8 can_r_available(void)
{
  return (C1GSR & RBS_BIT_READ) ? 1 : 0;  
}

// Check CAN message and set indicator flags
void check_can_message(void)
{
   CAN1_Rx(&rxFrame);       // Receive CAN frame into rxFrame

   if(rxFrame.ID == 2)      // If message ID is 2 ? Left indicator
   {
     if(rxFrame.Data1 == 1)
	 {
	   l_s = 1;             // Enable left signal
	   r_s = 0;             // Disable right signal
	 }
	 else
	 {
	   l_s = 0;             // Turn off left signal
	 } 
   }
   else if(rxFrame.ID == 3) // If message ID is 3 ? Right indicator
   {
     if(rxFrame.Data1 == 1)
	 {
	   r_s = 1;             // Enable right signal
	   l_s = 0;             // Disable left signal
	 }
	 else
	 {
	   r_s = 0;             // Turn off right signal
	 }
   }
}

// Blink LEDs according to indicator flags
void Blink_leds(void)
{
    check_can_message();    // Always update CAN message status

    if(l_s == 1 && r_s == 0)  // Left indicator ON
	{
		for(i=1; i<=255; i+=(i+1))  // LED chase pattern for left side
		{
		  if(l_s == 0)       // Stop if left signal turned off
		    break;

		  WRITEBYTE(IOPIN0, LEDS, ~i);  // Update LED output
		  delay_ms(100);
		}
	}
	else if(r_s == 1 && l_s == 0) // Right indicator ON
	{
		for(i=0; i<=7; i++)  // LED pattern for right side using LUT
		{
		  if(r_s == 0)       // Stop if right signal turned off
		    break;

		  WRITEBYTE(IOPIN0, LEDS, ~(R_LUT[i]));
		  delay_ms(100);
		}
	}
	else
	{
	  IOSET0 = 0xFF << LEDS; // Turn OFF all LEDs when no signal active
	}
}

// Main program
int main()   
{   
	IODIR0 |= 0xFF << LEDS;   // Configure LED pins (P0.10 - P0.17) as output
	IOSET0 = 0xFF << LEDS;    // Initially turn OFF all LEDs

	Initlcd();                // Initialize LCD
    Init_CAN1();              // Initialize CAN controller

	strlcd("indicator:");     // Display title on LCD

	while(1)                  // Infinite loop
	{
	    //if(can_r_available()) // Optional: Check CAN buffer before reading
	    check_can_message();   // Process received CAN message

        // Show left/right flags on LCD based on message ID
	    if(rxFrame.ID == 2)    
        {
	        cmdlcd(0xc0);      // Move cursor to 2nd line
            U32lcd(l_s);       // Display left flag
            U32lcd(r_s);       // Display right flag
	    }

	    if(rxFrame.ID == 3)
        {
            cmdlcd(0x94);      // Move cursor to 3rd line
            U32lcd(l_s);       // Display left flag
	        U32lcd(r_s);       // Display right flag
	    }

	    Blink_leds();          // Update LED patterns
	}
}
