#include<LPC21XX.h>               // Include LPC21XX microcontroller register definitions
#include"type.h"                   // Include custom type definitions (u8, u32, etc.)
#include"rtc.h"                    // Include RTC (Real Time Clock) functions
#include"pin_connect_block.h"      // Include pin configuration definitions
#include"delay.h"                  // Include delay functions
#include"lcd__defines.h"           // Include LCD related macros and definitions
#include"lcd.h"                    // Include LCD driver functions
#include"external_interrupt.h"     // Include external interrupt functions
#include"ds18b20.h"                // Include DS18B20 temperature sensor functions
#include"can.h"                    // Include CAN protocol driver functions
#include"can_defines.h"            // Include CAN related macros and definitions

#define sw1 16                     // Define switch 1 connected to pin 16
#define sw2 14                     // Define switch 2 connected to pin 14

u32 flag1=0,flag2=0;               // Flags for switch presses

// Custom characters for LCD CGRAM
char cgram_lut[] = {0x0e,0x11,0x11,0x11,0x11,0x11,0x11,0x1f}; // Custom LUT
unsigned char left_arrow[8]={0x00,0x04,0x08,0x1F,0x08,0x04,0x00,0x00};  // Left arrow
unsigned char right_arrow[8]={0x00,0x04,0x02,0x1f,0x02,0x04,0x00,0x00}; // Right arrow

struct CAN_Frame txFrame;          // CAN transmit frame structure
struct CAN_Frame rxFrame;          // CAN receive frame structure

// Function to check if CAN message is available
u8 can_msg_available(void)
{
  return (C1GSR&RBS_BIT_READ)?1:0;  // Return 1 if receive buffer status bit is set, else 0
}

// Function to check if CAN transmit buffer is free
u8 can_t_msg(void)
{
  return ((C1GSR&TCS1_BIT_READ)==0); // Return 1 if transmit buffer is ready
}

main()
{
u32 temp;                           // Variable to store raw temperature reading
u8 tp,tpd;                           // Variables to store integer and decimal parts of temperature
s32 hour,min,sec;                    // Variables to store RTC time

Initlcd();                           // Initialize LCD
Init_CAN1();                         // Initialize CAN1
RTC_Init();                          // Initialize RTC

enable_EINT0();                      // Enable external interrupt 0
enable_EINT1();                      // Enable external interrupt 1

cmdlcd(GOTO_LINE1_POS0);             // Set LCD cursor to line 1, position 0
strlcd("DS18B20 Interface:");        // Display static text on LCD
delay_ms(2000);                      // Wait for 2 seconds

while(1)                             // Infinite loop
{
    temp=ReadTemp();                 // Read temperature from DS18B20
    tp=temp>>4;                      // Extract integer part of temperature
    tpd=temp&0x08?0x35:0x30;        // Extract fractional part (0.5�C or 0�C)

    cmdlcd(GOTO_LINE2_POS0);         // Move cursor to line 2, position 0
    strlcd("Temp=");                 // Display "Temp=" text

    cmdlcd(0xC0+5);                  // Move cursor to position for integer part
    S32lcd(tp);                      // Display integer part of temperature

    cmdlcd(0xC0+7);                  // Move cursor to decimal point
    charlcd('.');                    // Display '.'

    cmdlcd(0xC0+8);                  // Move cursor to fractional part
    charlcd(tpd);                    // Display fractional part
    charlcd(223);                    // Display degree symbol

    cmdlcd(0xC0+9);                  // Move cursor to next position
    strlcd("C");                      // Display Celsius unit

    GetRTCTime(&hour,&min,&sec);      // Read current RTC time
    DisplayRTCTime(hour,min,sec);     // Display RTC time on LCD

    buildcgram(left_arrow,8,0x94,0x40);  // Store left arrow in CGRAM at location 0x94
    charlcd(0);                          // Display left arrow

    buildcgram(right_arrow,8,0x96,0x48); // Store right arrow in CGRAM at location 0x96
    charlcd(1);                           // Display right arrow

    if(can_t_msg())                       // Check if CAN transmit buffer is free
    {
         if(flag1==1 && flag2==0)         // If flag1 set and flag2 not set
         {
           txFrame.ID=2;                  // Set CAN ID to 2
           txFrame.vbf.RTR=0;             // Set frame as data frame
           txFrame.vbf.DLC=1;             // Set data length to 1 byte
           txFrame.Data1=1;               // Set data to 1
           CAN1_Tx(txFrame);              // Transmit CAN frame
           cmdlcd(0x94);                  // Move cursor to left arrow position
           strlcd(" ");                    // Clear previous character
           delay_ms(200);                  // Delay 200 ms
           buildcgram(left_arrow,8,0x94,0x40); // Rebuild left arrow
           charlcd(0);                     // Display left arrow
           delay_ms(200);
         }
        else if(flag1>1)                   // If flag1 exceeds 1
        {
          flag1=0;                         // Reset flag1
          txFrame.ID=2;                     // Set CAN ID to 2
          txFrame.vbf.RTR=0;                // Data frame
          txFrame.vbf.DLC=1;                // 1 byte data
          txFrame.Data1=0;                  // Data 0
          CAN1_Tx(txFrame);                 // Transmit frame
          buildcgram(left_arrow,8,0x94,0x40);  // Rebuild left arrow
          charlcd(0);                        // Display left arrow
          buildcgram(right_arrow,8,0x96,0x48); // Rebuild right arrow
          charlcd(1);                        // Display right arrow
        }

        if(flag2==1 && flag1==0)             // If flag2 set and flag1 not set
        {
           txFrame.ID=3;                     // Set CAN ID to 3
           txFrame.vbf.RTR=0;                // Data frame
           txFrame.vbf.DLC=1;                // 1 byte
           txFrame.Data1=1;                  // Data = 1
           CAN1_Tx(txFrame);                 // Transmit
           cmdlcd(0x96);                     // Move cursor to right arrow
           strlcd(" ");                       // Clear previous character
           delay_ms(200);                     // Delay 200 ms
           buildcgram(right_arrow,8,0x96,0x48); // Rebuild right arrow
           charlcd(1);                        // Display right arrow
           delay_ms(200);
        }
        else if(flag2>1)                      // If flag2 exceeds 1
        {
          flag2=0;                            // Reset flag2
          txFrame.ID=3;                        // Set CAN ID 3
          txFrame.vbf.RTR=0;                   // Data frame
          txFrame.vbf.DLC=1;                   // 1 byte data
          txFrame.Data1=0;                     // Data = 0
          CAN1_Tx(txFrame);                    // Transmit
          buildcgram(left_arrow,8,0x94,0x40);  // Rebuild left arrow
          charlcd(0);                           // Display left arrow
          buildcgram(right_arrow,8,0x96,0x48); // Rebuild right arrow
          charlcd(1);                           // Display right arrow
        }
    }

    if(can_msg_available())                  // Check if CAN message received
    {
        CAN1_Rx(&rxFrame);                   // Receive CAN frame
        if(rxFrame.ID==4)                    // If CAN ID is 4
        {
                cmdlcd(0xd4);                // Move cursor to display position
                strlcd("      ");            // Clear previous value
                cmdlcd(0xd4);                // Reset cursor
                U32lcd(rxFrame.Data1);       // Display received data
                cmdlcd(0xd4+2);              // Move cursor for '%' symbol
                charlcd('%');                // Display percentage
        }
    }
	}		
}
