#ifndef __CAN_H__           // Include guard start to prevent multiple inclusion
#define __CAN_H__

#include "type.h"          // Include type definitions like u32, u8

// Structure to represent a CAN frame
struct CAN_Frame
{
    u32 ID;                // 11-bit or 29-bit CAN message identifier

    // Bitfield for frame control
    struct BitField
    {
        u8 RTR : 1;        // Remote Transmission Request bit: 0 = data frame, 1 = remote frame
        u8 DLC : 4;        // Data Length Code: number of data bytes (0�8)
    } vbf;                 // Named variable for bitfield

    u32 Data1, Data2;      // Data bytes of CAN frame (total 8 bytes)
};

// Function to initialize CAN1 peripheral
void Init_CAN1(void);

// Function to transmit a CAN frame
void CAN1_Tx(struct CAN_Frame);

// Function to receive a CAN frame
void CAN1_Rx(struct CAN_Frame *);

#endif                      // Include guard end
