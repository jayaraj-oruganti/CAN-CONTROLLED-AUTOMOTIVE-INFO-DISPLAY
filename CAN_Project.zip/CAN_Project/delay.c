#include "type.h"                  // Include custom type definitions (u32, etc.)

// Delay in microseconds
void delay_us(u32 dlyUS)
{
    dlyUS *= 12;                   // Adjust for CPU clock cycles (1 �s � 12 cycles @ 12 MHz PCLK)
    while (dlyUS--);               // Busy-wait loop (counts down until 0)
}

// Delay in milliseconds
void delay_ms(u32 dlyMS)
{
    dlyMS *= 12000;                // 1 ms � 12000 cycles @ 12 MHz PCLK
    while (dlyMS--);               // Busy-wait loop
}

// Delay in seconds
void delay_s(u32 dlyS)
{
    dlyS *= 12000000;              // 1 s � 12,000,000 cycles @ 12 MHz PCLK
    while (dlyS--);                // Busy-wait loop
}
