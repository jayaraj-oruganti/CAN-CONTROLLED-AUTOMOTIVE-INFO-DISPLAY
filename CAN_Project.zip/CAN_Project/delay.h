#include "type.h"   // Include the header file that defines standard types like u32

/* Function prototypes for delay routines */

/* Delay for 'dlyUS' microseconds */
void delay_us(u32 dlyUS);  
// u32 = unsigned 32-bit integer (from type.h)
// dlyUS specifies the delay duration in microseconds

/* Delay for 'dlyMS' milliseconds */
void delay_ms(u32 dlyMS);  
// dlyMS specifies the delay duration in milliseconds

/* Delay for 'dlYS' seconds */
void delay_s(u32 dlYS);    
// dlYS specifies the delay duration in seconds
