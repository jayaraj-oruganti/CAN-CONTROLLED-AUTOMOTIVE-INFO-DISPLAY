#include <lpc21xx.h>          // Include LPC214x register definitions
#include "type.h"             // Include custom type definitions (u32, s32, etc.)

void RTC_Init(void);                          // Initialize RTC peripheral

// Functions to get RTC time (hours, minutes, seconds)
void GetRTCTime(s32 *, s32 *, s32 *); // Read current time from RTC into given pointers
void DisplayRTCTime(u32 , u32 , u32 );// Display the RTC time values

// Functions to get RTC date (day, month, year)
void GetRTCDate(s32 *, s32 *, s32 *); // Read current date from RTC
void DisplayRTCDate(u32 , u32, u32 );// Display the RTC date values

// Functions to set RTC time & date
void SetRTCTime(u32 , u32 , u32 );        // Set RTC time
void SetRTCDate(u32 , u32 , u32 );    // Set RTC date

// Functions to get/set RTC day of week
void GetRTCDay(s32 *);        // Read RTC day of week
void DisplayRTCDay(u32 );     // Display RTC day of week
void SetRTCDay(u32 );         // Set RTC day of week

// Individual setters for time & date fields
void SetRTCHour(u32 );         // Set RTC hour
void SetRTCMin(u32 );         // Set RTC minute
void SetRTCSec(u32 );         // Set RTC second
void SetRTCMonth(u32);     // Set RTC month
void SetRTCYear(u32);       // Set RTC year
void SetRTCDay(u32);         // Set RTC day (duplicate prototype, same as above)

// Individual getters for time & date fields
void GetRTCHour(s32 *);        // Get RTC hour
void GetRTCMin(s32 *);        // Get RTC minute
void GetRTCSec(s32 *);        // Get RTC second
void GetRTCMonth(s32 *);    // Get RTC month
void GetRTCYear(s32 *);      // Get RTC year

void GetDay(void);               // Get current day (likely prints/returns formatted day)
