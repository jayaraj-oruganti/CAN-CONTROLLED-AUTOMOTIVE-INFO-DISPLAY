#include <LPC21xx.h>        // LPC214x register definitions
#include "type.h"           // Custom type definitions (u32, etc.)
#include "can.h"            // CAN frame structure and function prototypes
#include "can_defines.h"    // CAN register/bit defines


/* CAN Controller 1 Initialization */
void Init_CAN1(void)
{
    // Configure P0.25 pin as CAN1_RX pin (RD1).  
    // TD1 (CAN1_TX) is exclusive and does not need multiplexing here.
    PINSEL1 |= RD1_PIN;   // #define RD1_PIN 0x00040000 ? configures P0.25 as RD1 (CAN1_RX)

    // Reset CAN1 controller (put into reset mode)
    C1MOD = 1;

    // Accept all received messages (bypass acceptance filtering)
    AFMR = 2;

    // Set baud rate for CAN communication
    C1BTR = BTR_LVAL;     // Value comes from can_defines.h

    // Enable CAN1 controller (exit reset mode)
    C1MOD = 0;
}


/* CAN1 Transmit Function */
void CAN1_Tx(struct CAN_Frame txFrame)
{
    // Wait until TX buffer is empty ? check C1GSR.TBS1 (Transmit Buffer Status)
    while ((C1GSR & TBS1_BIT_READ) == 0);

    // Place 11-bit CAN ID in C1TID1 register
    C1TID1 = txFrame.ID;

    // Configure Frame Information Register:
    // - RTR (Remote Transmission Request) bit
    // - DLC (Data Length Code) ? number of data bytes
    C1TFI1 = txFrame.vbf.RTR << 30 | txFrame.vbf.DLC << 16;

    // If it is a Data Frame (RTR = 0), load data into transmit buffers
    if (txFrame.vbf.RTR != 1)
    {
        // Load first 4 bytes into C1TDA1
        C1TDA1 = txFrame.Data1;

        // Load next 4 bytes into C1TDB1
        C1TDB1 = txFrame.Data2;
    }

    // Select Transmit Buffer 1 & Start transmission
    C1CMR = STB1_BIT_SET | TR_BIT_SET;

    // Wait until transmission is complete ? check C1GSR.TCS1 (Transmit Complete Status)
    while ((C1GSR & TCS1_BIT_READ) == 0);
}


/* CAN1 Receive Function */
void CAN1_Rx(struct CAN_Frame *rxFrame)
{
    // Wait until a CAN frame is received (C1GSR.RBS bit set)
    while ((C1GSR & RBS_BIT_READ) == 0);

    // Read 11-bit CAN ID of the received frame
    rxFrame->ID = C1RID;

    // Extract frame type (Data/Remote) from C1RFS (bit 30)
    rxFrame->vbf.RTR = (C1RFS >> 30) & 1;

    // Extract DLC (Data Length Code) from C1RFS (bits 16�19)
    rxFrame->vbf.DLC = (C1RFS >> 16) & 0x0F;

    // If it is a Data Frame, read the data bytes
    if (rxFrame->vbf.RTR == 0)
    {
        // Read first 4 data bytes
        rxFrame->Data1 = C1RDA;

        // Read next 4 data bytes
        rxFrame->Data2 = C1RDB;
    }

    // Release Receive Buffer so controller can accept new frames
    C1CMR = RRB_BIT_SET;
}
