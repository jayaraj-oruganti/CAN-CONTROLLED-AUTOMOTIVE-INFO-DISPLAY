#include "type.h"            // Custom type definitions: u8, u32, s32, f32, etc.
#include <LPC21XX.H>         // LPC21xx MCU register definitions
#include "lcd__defines.h"    // LCD pin & command defines like LCD_RS, LCD_EN
#include "defines.h"         // Generic project defines
#include "delay.h"           // Delay functions: delay_us(), delay_ms()
#include "lcd.h"             // LCD function prototypes

// Write a byte to the LCD (data/command)
void writelcd(u8 byte) {
    SCLRBIT(IOCLR0,LCD_RW);               // Select WRITE operation (RW=0)
    WRITEBYTE(IOPIN0,LCD_DATA,byte);      // Write cmd/ascii value to data pins
    SSETBIT(IOSET0,LCD_EN);               // Set ENABLE pin high
    delay_us(1);                           // Wait for >= 450 ns (LCD timing)
    SCLRBIT(IOCLR0,LCD_EN);               // Clear ENABLE pin
    delay_ms(2);                           // Wait for LCD to process byte
}

// Send a command to LCD
void cmdlcd(u8 cmd) {
    SCLRBIT(IOCLR0,LCD_RS);               // RS=0 for command (instruction register)
    writelcd(cmd);                         // Write command to LCD
}

// Initialize LCD
void Initlcd(void) {
    WRITEBYTE(IODIR0,LCD_DATA,0xFF);      // Configure LCD data port as output
    SETBIT(IODIR0,LCD_RS);                // RS pin as output
    SETBIT(IODIR0,LCD_RW);                // RW pin as output
    SETBIT(IODIR0,LCD_EN);                // EN pin as output
    delay_ms(15);                          // Wait for LCD power-up (>15ms)
    
    cmdlcd(0x30);                          // Function set cmd
    delay_ms(5);                            // Wait >=4.1ms
    cmdlcd(0x30);                          // Repeat function set cmd
    delay_us(100);                          // Wait >=100us
    cmdlcd(0x30);                          // Repeat function set cmd
    cmdlcd(0x02);                           // Return home (cursor to 0,0)
    cmdlcd(0x38);                           // 8-bit mode, 2-line display
    cmdlcd(0x0C);                           // Display ON, cursor OFF (programmer choice)
    cmdlcd(0x01);                           // Clear display
    cmdlcd(0x06);                           // Entry mode: cursor moves right
}

// Write a single character to LCD
void charlcd(u8 asciiVal) {
    SSETBIT(IOSET0,LCD_RS);               // RS=1 for data (DDR)
    writelcd(asciiVal);                    // Write character to LCD
}

// Write a string to LCD
void strlcd(s8 *str) {   
    while(*str) {                           // Loop until null terminator
        charlcd(*str++);                    // Print each character and increment pointer
    }
}

// Display unsigned 32-bit integer
void U32lcd(u32 num) {
    u8 a[10];                               // Array to store extracted digits as chars
    s16 i=0;                                // Array index

    if(num==0) {                             // Special case: num=0
        charlcd('0');                        // Print '0'
    }
    else {
        while(num) {                         // Loop until all digits extracted
            a[i++] = (num%10)+'0';           // Convert digit to ASCII and store
            num /= 10;                        // Remove last digit
        }
    }
    for(--i; i>=0; i--) {                     // Print digits in correct order
        charlcd(a[i]);
    }
}

// Display signed 32-bit integer
void S32lcd(s32 num) {
    if(num<0) {                               // Check if negative
        num = -num;                           // Make positive
        charlcd('-');                         // Print minus sign
    }
    U32lcd(num);                               // Print magnitude
}

// Display float with specified decimal points
void F32lcd(f32 num, u32 nDp) {  
    u32 i_num;

    if (num < 0.0) {                          // Negative float
        num = -num;                            
        charlcd('-');                          // Print minus
    }

    i_num = num;                               // Extract integer part
    U32lcd(i_num);                             // Display integer part
    charlcd('.');                              // Print decimal point

    while(nDp--) {                             // Loop for decimal digits
        num = (num - i_num) * 10;             // Shift next decimal digit to integer
        i_num = num;                           // Extract digit
        charlcd(i_num + 0x30);                 // Convert digit to ASCII and print
    }
}

// Write custom characters to CGRAM
void buildcgram(u8 *p, u8 nbytes, int goto_line1_pos0, int goto_cgram_start) {
    u32 i;

    cmdlcd(goto_cgram_start);                  // Set CGRAM start address
    for(i=0; i<nbytes; i++) {                  // Loop through all custom bytes
        charlcd(p[i]);                          // Write byte to CGRAM
    }
    cmdlcd(goto_line1_pos0);                    // Return cursor to desired position
}
