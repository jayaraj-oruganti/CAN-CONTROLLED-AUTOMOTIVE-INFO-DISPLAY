//defines required for C1BTR in can_defines.h     

#ifndef __CAN_DEFINES_H__   // Header guard start to prevent multiple inclusion
#define __CAN_DEFINES_H__   // Define the header guard

#include "type.h"   // Include type definitions (custom header, usually typedefs for uint, etc.)

#define RD1_PIN 0x00040000   // Pin definition for RD1 (Receive Data 1 pin)

#define pCLK       60000000  //Hz    // Peripheral clock frequency set to 60 MHz

#define BIT_RATE   125000    //Hz    // CAN bus bit rate set to 125 kbps

#define QUANTA     16        // Number of time quanta per bit

#define BRP        (pCLK/(BIT_RATE*QUANTA))    // Baud Rate Prescaler value

#define SAMPLE_POINT  (0.7 * QUANTA)    // Sample point at 70% of the bit time

#define TSEG1        ((int)SAMPLE_POINT-1)  // TSEG1 = Propagation segment + Phase segment 1

#define TSEG2        (QUANTA-(1+TSEG1))   // TSEG2 = Phase segment 2

#define SJW          ((TSEG2 >= 5)   ?   4 : (TSEG2-1))     // Synchronization Jump Width

#define SAM          0 //0 or 1 , sample bus 1 or 3 time(s)    // Sampling mode: 0 = once, 1 = three times

#define BTR_LVAL    (SAM<<23|(TSEG2-1)<<20|(TSEG1-1)<<16|(SJW-1)<<14|(BRP-1))    // Bit Timing Register (low value) setup

//defines for C1CMR bit set     

#define TR_BIT_SET   1<<0     // Transmission Request bit set
#define RRB_BIT_SET  1<<2     // Release Receive Buffer bit set
#define STB1_BIT_SET 1<<5     // Command to select Transmission Buffer 1

//defines for C1GSR bit check     

#define RBS_BIT_READ  1<<0     // Receive Buffer Status bit check
#define TBS1_BIT_READ 1<<2     // Transmission Buffer 1 Status bit check
#define TCS1_BIT_READ 1<<3     // Transmission Complete Status bit check

//defines for C1CMR bit set

#define TR_BIT_SET   1<<0     // Transmission Request bit set (duplicate definition)
#define RRB_BIT_SET  1<<2     // Release Receive Buffer bit set (duplicate definition)
#define STB1_BIT_SET 1<<5     // Select Transmission Buffer 1 (duplicate definition)

//defines for C1GSR bit check

#define RBS_BIT_READ  1<<0    // Receive Buffer Status bit check (duplicate definition)
#define TBS1_BIT_READ 1<<2    // Transmission Buffer 1 Status bit check (duplicate definition)
#define TCS1_BIT_READ 1<<3    // Transmission Complete Status bit check (duplicate definition)

#endif   // End of header guard
