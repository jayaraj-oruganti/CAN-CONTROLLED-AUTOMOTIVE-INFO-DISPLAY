#include "type.h"                            // Include custom type definitions (u32, etc.)

void CfgPortPinFunc(u32 portNo,              // Function to configure a specific port pin function
                    u32 pinNo,               // Pin number within the port
                    u32 pinF);               // Function to assign to that pin (GPIO, ADC, UART, etc.)
