#include <LPC21xx.h>
#include "delay.h"

#define D (1 << 15)      // DS18B20 data line on P0.15
#define R (IOPIN0 & D)   // Read pin state (masking only bit 15)


/** RESET FUNCTION for DS18B20 **/
u8 ResetDS18b20(void)
{
    u32 presence; 

    IODIR0 |= D;         // Configure P0.15 as output
    IOPIN0 |= D;         // Pull line HIGH (idle state)
    delay_us(1);         // Recovery time ~1 �s

    IOPIN0 &= ~(D);      // Pull line LOW (RESET pulse)
    delay_us(478);       // Hold for >480 �s (reset timing)

    IOPIN0 |= D;         // Release line (go HIGH)
    delay_us(54);        // Wait 60-70 �s for presence pulse

    presence = IOPIN0;   // Read presence from sensor
    delay_us(423);       // Wait for presence pulse end

    if (presence & R)    // If line still HIGH ? no device
        return 1;        // No presence detected
    else 
        return 0;        // Presence detected
}


/** READ A SINGLE BIT from DS18B20 **/
u8 ReadBit(void)
{
    u32 B;	

    IOPIN0 &= ~(D);      // Pull line LOW to start read slot
    delay_us(1);         // Keep low for >1 �s

    IOPIN0 |= D;         // Release line
    IODIR0 &= ~(D);      // Configure as input (read mode)
    delay_us(10);        // Wait ~15 �s (sample timing)

    B = IOPIN0;          // Read line state

    IODIR0 |= D;         // Reconfigure as output
    if (B & R) 
        return 1;        // Return bit value
    else 
        return 0;
}


/** WRITE A SINGLE BIT into DS18B20 **/
void WriteBit(u8 Dbit)
{
    IOPIN0 &= ~(D);      // Pull line LOW to start write slot
    delay_us(1);         // Hold for >1 �s

    if (Dbit) 
        IOPIN0 |= D;     // If writing '1', release early
    // If writing '0', keep LOW

    delay_us(58);        // Slot time ~60 �s
    IOPIN0 |= D;         // Release line
    delay_us(1);         // Recovery time
}


/** READ A BYTE (8 bits) **/
u8 ReadByte(void)
{
    u8 i, Din = 0;

    for (i = 0; i < 8; i++)
    {
        if (ReadBit())         // Read each bit
            Din |= (1 << i);   // Store in LSB first order
        delay_us(45);          // Slot recovery time
    }

    return Din;
}


/** WRITE A BYTE (8 bits) **/
void WriteByte(u8 Dout)
{
    u8 i;

    for (i = 0; i < 8; i++)
    {	    
        WriteBit(Dout & 0x01); // Write LSB first
        Dout >>= 1;            // Shift to next bit
        delay_us(1);           // Small delay between slots
    }

    delay_us(98);              // End of byte slot time
}


/** READ TEMPERATURE from DS18B20 **/
int ReadTemp(void)
{
    u8 n, buff[2];
    int temp;

    ResetDS18b20();       // Reset and detect presence
    WriteByte(0xCC);      // SKIP ROM (single device)
    WriteByte(0x44);      // CONVERT T (start temperature conversion)

    while (ReadByte() == 0xFF); // Wait until conversion complete

    ResetDS18b20();
    WriteByte(0xCC);      // SKIP ROM
    WriteByte(0xBE);      // READ SCRATCHPAD

    for (n = 0; n < 2; n++)
    {
        buff[n] = ReadByte();  // Read 2 bytes (LSB + MSB)
    }

    temp = buff[1];       // MSB
    temp <<= 8;
    temp |= buff[0];      // LSB

    return temp;          // Raw 16-bit temperature value
}
