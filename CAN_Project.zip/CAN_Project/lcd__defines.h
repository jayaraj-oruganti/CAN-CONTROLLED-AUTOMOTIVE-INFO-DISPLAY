#ifndef _LCD__DEFINES_H        // Start of include guard to prevent multiple inclusion
#define _LCD__DEFINES_H        // Define the unique identifier for this header file

// HD44780 Commands (LCD controller standard commands)
#define CLEAR_LCD          0x01   // Clear display and return cursor to home
#define RET_CUR_HOME       0x02   // Return cursor to home position without clearing display
#define SHIFT_CUR_RIGHT    0x14   // Move cursor one step to the right
#define SHIFT_CUR_LEFT     0x10   // Move cursor one step to the left
#define DSP_OFF            0x08   // Display off, cursor off
#define DSP_ON_CUR_OFF     0x0C   // Display on, cursor off
#define DSP_ON_CUR_ON      0x0E   // Display on, cursor on (steady)
#define DSP_ON_CUR_BLINK   0x0F   // Display on, cursor blinking
#define SHIFT_DSP_LEFT     0x18   // Shift entire display left
#define SHIFT_DSP_RIGHT    0x1C   // Shift entire display right
#define MODE_8BIT_1LINE    0x30   // 8-bit interface, 1 line display, 5x7 dots
#define MODE_8BIT_2LINE    0x38   // 8-bit interface, 2 line display, 5x7 dots
#define MODE_4BIT_1LINE    0x20   // 4-bit interface, 1 line display, 5x7 dots
#define MODE_4BIT_2LINE    0x28   // 4-bit interface, 2 line display, 5x7 dots
#define GOTO_LINE1_POS0    0x80   // Move cursor to line 1, position 0
#define GOTO_LINE2_POS0    0xC0   // Move cursor to line 2, position 0
#define GOTO_LINE3_POS0    0x94   // Move cursor to line 3, position 0 (for 20x4 LCD)
#define GOTO_LINE4_POS0    0xD4   // Move cursor to line 4, position 0 (for 20x4 LCD)
#define GOTO_CGRAM_START   0x40   // Set CGRAM (Character Generator RAM) address

// LCD pin connections (to microcontroller pins)
#define LCD_DATA            0     // LCD data lines connected to P0.0�P0.7
#define LCD_RS              8     // LCD RS (Register Select) pin connected to P0.8
#define LCD_EN              9     // LCD EN (Enable) pin connected to P0.9
#define LCD_RW              18    // LCD RW (Read/Write) pin connected to P0.18

#endif                           // End of include guard
