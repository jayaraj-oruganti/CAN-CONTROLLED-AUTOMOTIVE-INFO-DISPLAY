#include <LPC21XX.h>        // LPC21xx microcontroller header
#include "can.h"            // CAN driver functions
#include "delay.h"          // Delay functions
#include "can_defines.h"    // CAN register/bit defines
#include "type.h"           // Data type aliases (u8, s32, etc.)

#define led 0               // Starting pin for LED connection (P0.0 ? P0.7)

int main()
{
    // Lookup table for LED ON/OFF pattern (active low)
    // Each value clears one bit at a time
    u8 arr[8] = {0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe};

//    s32 i;
    struct CAN_Frame rxFrame;   // CAN frame for receiving data   

    Init_CAN1();                // Initialize CAN controller
    IODIR0 |= 0xFF << led;      // Configure P0.0 - P0.7 as output
    delay_s(2);                 // Small delay at startup
    IOPIN0 = 0xFF << led;       // Initially turn OFF all LEDs (active low)

    /* ---------------- MAIN LOOP ----------------
    while(1)   
    {
        // Check if a CAN message is received
        if(((C1GSR & RBS_BIT_READ) == 1))   
        {  
	        CAN1_Rx(&rxFrame);   // Read the CAN frame
        }

        // ---- LEFT INDICATOR ON ----
        if((rxFrame.ID==1) && (rxFrame.Data1=='L') && (rxFrame.Data2==0x00))
        {
            // Run LED pattern from left to right
            for(i=0; i<=7; i++)
            {
                IOPIN0 = arr[i] << led;   // Update LEDs
                delay_ms(100);
            }
        }

        // ---- LEFT INDICATOR OFF ----
        else if((rxFrame.ID==1) && (rxFrame.Data1=='L') && (rxFrame.Data2==0xFF))
        {
            IOPIN0 = 0xFF << led;        // Turn OFF all LEDs
            delay_ms(200);
        }

        // ---- RIGHT INDICATOR ON ----
        else if((rxFrame.ID==1) && (rxFrame.Data1=='R') && (rxFrame.Data2==0x00))
        {
            // Run LED pattern from right to left
            for(i=7; i>=0; i--)
            {
                IOPIN0 = arr[i] << led;  // Update LEDs
                delay_ms(100);
            }
        }

        // ---- RIGHT INDICATOR OFF ----
        else if((rxFrame.ID==1) && (rxFrame.Data1=='R') && (rxFrame.Data2==0xFF))
        {
            IOPIN0 = 0xFF << led;        // Turn OFF all LEDs
            delay_ms(200); 
        }
    }
    ------------------------------------------------ */
}
