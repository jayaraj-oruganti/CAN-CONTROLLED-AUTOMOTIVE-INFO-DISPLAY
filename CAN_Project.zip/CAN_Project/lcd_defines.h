#define CLEAR_LCD        0x01   // Clear display and return cursor to home
#define RET_CUR_HOME     0x02   // Return cursor to home (address 0), DDRAM unchanged
#define SHIFT_CUR_RIGHT  0x06   // Shift cursor right (with entry mode set)
#define SHIFT_CUR_LEFT   0x07   // Shift cursor left (with entry mode set)
#define DSP_OFF          0x08   // Display off, cursor off
#define DSP_0C_CUR_OFF   0x0C   // Display on, cursor off
#define DSP_ON_CUR_ON    0x0E   // Display on, cursor on (steady)
#define DSP_ON_CUR_BLK   0x0F   // Display on, cursor blinking
#define SHIFT_DSP_LEFT   0x10   // Shift entire display to the left
#define SHIFT_DSP_RIGHT  0x14   // Shift entire display to the right
#define MODE_8BIT_1LINE  0x30   // 8-bit interface, 1 line, 5x7 dots
#define MODE_4BIT_1LINE  0x20   // 4-bit interface, 1 line, 5x7 dots
#define MODE_8BIT_2LINE  0x38   // 8-bit interface, 2 lines, 5x7 dots
#define MODE_4BIT_2LINE  0x28   // 4-bit interface, 2 lines, 5x7 dots
#define GOTO_LINE1_POS0  0x80   // Move cursor to Line 1, position 0
#define GOTO_LINE2_POS0  0xC0   // Move cursor to Line 2, position 0
#define GOTO_LINE3_POS0  0x94   // Move cursor to Line 3, position 0 (for 20x4 LCD)
#define GOTO_LINE4_POS0  0xD4   // Move cursor to Line 4, position 0 (for 20x4 LCD)
#define GOTO_CGRAM_START 0x40   // Set CGRAM (custom character memory) start address

// LCD pin connections with microcontroller
#define lcd_data 0   // LCD data lines connected to P0.8�P0.15
#define lcd_rs   8   // RS (Register Select) pin ? P0.8
#define lcd_rw   10  // RW (Read/Write) pin ? P0.10
#define lcd_en   9   // EN (Enable) pin ? P0.9
