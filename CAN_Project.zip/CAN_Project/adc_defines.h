#ifndef _ADC_DEFINES_H_       // Include guard start to prevent multiple inclusion
#define _ADC_DEFINES_H_

// Defines for ADCR (A/D Control Register) channels
#define CH0      0x01          // ADC channel 0
#define CH1      0x02          // ADC channel 1
#define CH2      0x04          // ADC channel 2
#define CH3      0x08          // ADC channel 3

#define CHANNEL_SEL   CH0      // Select ADC channel(s) to convert (currently CH0)
                            // Example: CH0 | CH1 for multiple channels

// System clock and ADC clock configuration
#define FOSC          12000000 // Oscillator frequency = 12 MHz
#define CCLK          (5 * FOSC) // CPU Clock (CCLK) = 5 * FOSC
#define PCLK          (CCLK/4)   // Peripheral Clock (PCLK) = CCLK / 4

#define ADCLK         3000000     // Desired ADC clock = 3 MHz
#define CLKDIV        (((PCLK/ADCLK)-1)<<8)  
                            // Clock divider for ADC (set in ADCR[15:8])
                            // Divider = (PCLK / ADCLK) - 1, shifted to correct bits

// ADCR control bits
#define PDN_BIT       (1<<21)    // Power-down bit: 1 = ADC enabled, 0 = powered down
#define ADC_START_BIT 24          // Start bit position in ADCR register

// Defines for ADxDR (A/D Data Register)
#define DONE_BIT      31          // DONE bit position in ADxDR: 1 = conversion complete

#endif                        // Include guard end
