/* defines.h */

#ifndef __DEFINES_H__          // Include guard start: prevents multiple inclusions
#define __DEFINES_H__


/* ---------------- Bit Manipulation Macros ---------------- */

/* Set a specific bit (BITPOS) in WORD */
#define SETBIT(WORD,BITPOS)            (WORD |= 1 << BITPOS)      
// WORD = WORD OR (1 shifted left by BITPOS), sets the bit without changing others

/* Clear a specific bit (BITPOS) in WORD */
#define CLRBIT(WORD,BITPOS)            (WORD &= ~(1 << BITPOS))   
// WORD = WORD AND NOT (1 shifted left by BITPOS), clears the bit

/* Complement (toggle) a specific bit (BITPOS) in WORD */
#define CPLBIT(WORD,BITPOS)            (WORD ^= 1 << BITPOS)      
// WORD = WORD XOR (1 shifted left by BITPOS), flips the bit

/* Write a specific bit (BITPOS) in WORD with value BIT (0 or 1) */
#define WRITEBIT(WORD,BITPOS,BIT)      WORD = ((WORD & ~(1 << BITPOS)) | (BIT << BITPOS))  
// Clears the bit at BITPOS, then ORs in BIT shifted to BITPOS

/* Read a specific bit (BITPOS) from WORD */
#define READBIT(WORD,BITPOS)           ((WORD >> BITPOS) & 1)    
// Shift WORD right by BITPOS, mask LSB to get the bit value

/* Read a bit from RBIT position and write it into WBIT position */
#define READWRITEBIT(WORD,WBIT,RBIT)   WORD = (((WORD & ~(1 << WBIT)) | ((WORD >> RBIT) & 1) << WBIT))  
// Clears WBIT, reads bit from RBIT, shifts it to WBIT, and writes it into WORD

/* Write lower 4 bits of BYTE into WORD at BITPOS (nibble manipulation) */
#define WRITENIBBLE(WORD,BITPOS,BYTE)  WORD = ((WORD & ~(0x0000000F << BITPOS)) | ((BYTE & 0x0F) << BITPOS))  
// Clears 4 bits at BITPOS, masks BYTE to 4 bits, shifts it to BITPOS, and writes to WORD

/* Read 4 bits (nibble) from WORD at BITPOS */
#define READNIBBLE(WORD,BITPOS)        ((WORD >> BITPOS) & 0x0000000F)   
// Shifts WORD right by BITPOS and masks lower 4 bits to get the nibble

/* Write 8 bits of BYTE into WORD at BITPOS (byte manipulation) */
#define WRITEBYTE(WORD,BITPOS,BYTE)    WORD = ((WORD & ~(0x000000FF << BITPOS)) | (BYTE << BITPOS))  
// Clears 8 bits at BITPOS, shifts BYTE to BITPOS, ORs it into WORD

/* Read 8 bits (byte) from WORD at BITPOS */
#define READBYTE(WORD,BITPOS)          ((WORD >> BITPOS) & 0x000000FF)  
// Shifts WORD right by BITPOS, masks lower 8 bits to get the byte


/* ---------------- Single Bit Set/Clear Macros ---------------- */

/* Set WORD to only have BITPOS bit set (all other bits cleared) */
#define SSETBIT(WORD,BITPOS)           (WORD = 1 << BITPOS)       
// WORD = 1 shifted to BITPOS, all other bits become 0

/* Clear a bit in WORD */
#define SCLRBIT SSETBIT   

#endif  // __DEFINES_H__  // Include guard end
